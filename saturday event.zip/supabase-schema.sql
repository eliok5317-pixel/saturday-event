-- ============================================================
-- Event Match — Supabase schema
-- Run this ONCE in your Supabase project's SQL Editor
-- (Dashboard → SQL Editor → New query → paste this whole file → Run)
-- ============================================================

create extension if not exists "pgcrypto";

-- Everyone who has checked in by scanning the QR code
create table guests (
  id uuid primary key default gen_random_uuid(),
  device_id text unique not null,        -- random id generated in the guest's browser (no login needed)
  name text not null,
  gender text not null check (gender in ('male','female','other')),
  hobby1 text not null,
  hobby2 text,
  description text not null,             -- "what are you wearing / describe yourself"
  single_status text not null check (single_status in ('single','not_single','prefer_not_to_say')),
  checked_in_at timestamptz not null default now(),
  match_id uuid                          -- filled in once they're matched
);

-- One row per pair once they've been matched
create table matches (
  id uuid primary key default gen_random_uuid(),
  guest_a uuid not null references guests(id),
  guest_b uuid not null references guests(id),
  secret_word text not null,
  created_at timestamptz not null default now()
);

-- Chat messages between a matched pair
create table messages (
  id uuid primary key default gen_random_uuid(),
  match_id uuid not null references matches(id),
  sender_device_id text not null,
  body text not null,
  created_at timestamptz not null default now()
);

-- ------------------------------------------------------------
-- Access policies
-- CUSTOMIZE: these are intentionally wide open (anyone with the anon
-- key — which is public by design in any Supabase web app — can read
-- and write). That's fine for a one-week event tool with no sensitive
-- data. If you want it locked down further afterwards, that's a
-- separate pass — just ask.
-- ------------------------------------------------------------
alter table guests enable row level security;
alter table matches enable row level security;
alter table messages enable row level security;

create policy "guests_select" on guests for select using (true);
create policy "guests_insert" on guests for insert with check (true);
create policy "guests_update" on guests for update using (true);

create policy "matches_select" on matches for select using (true);
create policy "matches_insert" on matches for insert with check (true);

create policy "messages_select" on messages for select using (true);
create policy "messages_insert" on messages for insert with check (true);

-- ------------------------------------------------------------
-- Turn on realtime so the app updates live without refreshing
-- ------------------------------------------------------------
alter publication supabase_realtime add table guests;
alter publication supabase_realtime add table matches;
alter publication supabase_realtime add table messages;

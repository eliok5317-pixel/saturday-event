# Match Night — setup guide

A QR-code check-in for your event: guests answer a few questions, you trigger
matching whenever you're ready, and each matched pair gets a secret word plus
a private chat to find each other in the room.

Stack: plain HTML/JS + Supabase (same as Storia) for the database. No build
step, no framework — just static files you deploy.

## 1. Create the Supabase project (5 min)

1. Go to [supabase.com](https://supabase.com) and create a **new** project
   (don't reuse the Storia one — keep this separate).
2. Once it's ready, go to **SQL Editor → New query**, paste in the entire
   contents of `supabase-schema.sql` from this folder, and click **Run**.
   This creates the three tables and turns on realtime.
3. Go to **Project Settings → API**. You'll need two values from here:
   - **Project URL**
   - **anon public** key

## 2. Fill in your config

Open `supabase-config.js` and replace the placeholders:

```js
window.SUPABASE_URL = "https://your-project-ref.supabase.co";
window.SUPABASE_ANON_KEY = "your-anon-public-key";
window.EVENT_NAME = "Whatever you're calling the night";
window.ADMIN_PASSCODE = "pick-something-only-you-know";
```

## 3. Deploy it (5–10 min)

Easiest path since you're already planning to use Vercel for Storia:

1. Go to [vercel.com](https://vercel.com) → **Add New → Project**.
2. Choose **"Deploy without Git"** / drag-and-drop, and drop this whole
   `event-match` folder onto the page. (Or push it to a new GitHub repo and
   import it the normal way — same result.)
3. Vercel gives you a URL like `https://your-project.vercel.app`. That's your
   guest-facing link — `index.html` is the homepage automatically.
4. Your host panel is that same URL + `/admin.html`, e.g.
   `https://your-project.vercel.app/admin.html`. Keep that one private —
   only share the main link at the door.

## 4. Make the QR code

Paste your Vercel URL into any free QR generator (e.g.
[qr-code-generator.com](https://www.qr-code-generator.com)) and print it out.
No account needed for a basic static QR code.

## 5. Test before the event

Open the main link on your phone and check in as a guest. Open it again in
an incognito window (or a friend's phone) and check in as a second person of
the opposite gender. Open `/admin.html`, enter your passcode, hit **Run
matching now**, and confirm both people get matched, see the secret word, and
can chat with each other in real time. This confirms the whole pipeline
works before you're relying on it live.

## How matching actually works

- You (the host) decide when to run it — hit **Run matching now** on the
  admin panel any time. It's safe to click repeatedly throughout the night
  as more people check in; it only pairs people who aren't matched yet.
- It pairs opposite genders first, prioritizing people with a shared hobby.
- If the room is lopsided (a lot more of one gender), or someone picked
  "other / prefer not to say," leftover people get paired with whoever's
  left by shared hobbies rather than left waiting forever.
- "Are you single" is shown to your match as a fun fact, not used to filter
  who gets matched — so it works whether tonight is more friendly-mixer or
  dating-style vibes. Say the word if you'd rather it gate strictly on
  "single" people only, and I'll adjust the logic.

## Things worth knowing

- **No moderation on chat.** It's a plain open chat between two matched
  people — no profanity filter, no reporting. Fine for a one-night student
  event; worth knowing if you'd want more control.
- **Database access is wide open** (anyone with the public key can read/write)
  rather than locked to logged-in users — this is what makes "no login, just
  scan and go" possible. There's no sensitive data in here (just names,
  hobbies, a one-line description, and a yes/no), so the tradeoff is
  reasonable for a short-lived event tool.
- **Free tier is plenty.** Supabase's free tier easily handles an event of
  this size; Vercel's free tier does too.
- Every spot you might want to tweak (colors, word lists, event name,
  passcode) is marked `CUSTOMIZE:` in the code.

## Files in this folder

| File | What it is |
|---|---|
| `index.html` | The guest page — check-in, waiting, match reveal, chat |
| `admin.html` | Your host panel — stats + the "run matching" button |
| `styles.css` | Shared styling |
| `supabase-config.js` | Your project keys + event name + passcode |
| `supabase-schema.sql` | Database setup — run once in Supabase |
